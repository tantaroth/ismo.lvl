@extends('layouts.manager')

@section('body')
	<h1>¡Hurrah!</h1>
	<p>¡Tenemos una plantilla!</p>
@stop