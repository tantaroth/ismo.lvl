<?php

class Categories extends Eloquent
{
	protected $table = "categories";
}