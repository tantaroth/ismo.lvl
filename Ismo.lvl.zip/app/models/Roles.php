<?php

class Roles extends Eloquent
{
	protected $table = "roles";
}