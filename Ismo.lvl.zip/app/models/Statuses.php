<?php

class Statuses extends Eloquent
{
	protected $table = "statuses";
}