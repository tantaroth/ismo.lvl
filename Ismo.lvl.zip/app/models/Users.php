<?php

class Users extends Eloquent
{
	protected $table = "users";
}