<?php

class Modules extends Eloquent
{
	protected $table = "modules";
}