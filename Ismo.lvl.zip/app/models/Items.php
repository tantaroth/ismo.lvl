<?php

class Items extends Eloquent
{
	protected $table = "items";
}