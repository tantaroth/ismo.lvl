<?php

class News extends Eloquent
{
	protected $table = "news";
}