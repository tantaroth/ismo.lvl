<?php

class Contents extends Eloquent
{
	protected $table = "contents";
}