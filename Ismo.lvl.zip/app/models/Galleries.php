<?php

class Galleries extends Eloquent
{
	protected $table = "galleries";
}