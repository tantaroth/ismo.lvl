<?php

class Socials extends Eloquent
{
	protected $table = "socials";
}