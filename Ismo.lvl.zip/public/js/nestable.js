
$(document).ready(function()
{

    $('#nestable3').nestable();

    /*plus*/


    $('.dd-collapsed .expand').css({'display':'block'});
    $('.dd-collapsed .collapse').css({'display':'none'});


});